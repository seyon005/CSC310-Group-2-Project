/* login and signup switch */
document.addEventListener("DOMContentLoaded", function () 
{
    const newToMediAlert = document.getElementById("newToMediAlert");
    const alreadyHaveAccount = document.getElementById("alreadyHaveAccount");
    const loginForm = document.querySelector(".login");
    const signupForm = document.querySelector(".Signup");

    newToMediAlert.addEventListener("click", function () 
    {
        signupForm.style.display = "block";
        setTimeout(() => {
            loginForm.style.display = "none";
            document.title = "Sign Up"
        }, 10);
    });

    alreadyHaveAccount.addEventListener("click", function () 
    {
        loginForm.style.display = "block";
        setTimeout(() => {
            signupForm.style.display = "none";
            document.title = "Login"
        }, 10);
    });
});

/*validation of fields in login and signup forms */
function validateLoginForm() 
{
    const usernameInput = document.querySelector('.login input[type="text"]');
    const passwordInput = document.querySelector('.login input[type="password"]');

    if (!usernameInput.value || !passwordInput.value) 
    {
        alert('Please fill in all required fields.');
    }
}
function validateSignupForm() 
{
    const firstnameInput = document.querySelector('.Signup input[type="text"]');
    const lastnameInput = document.querySelector('.Signup input[type="text"]');
    const usernameInput = document.querySelector('.Signup input[type="text"]');
    const emailInput = document.querySelector('.Signup input[type="email"]');
    const passwordInput = document.querySelector('.Signup input[type="password"]');

    if (!firstnameInput || !lastnameInput || !usernameInput || !emailInput  || !passwordInput.value) 
    {
        alert('Please fill in all required fields.');
    }
}

/* validation of email */
document.addEventListener("DOMContentLoaded", function () 
{
    const emailInput = document.getElementById("email");
    const submitButton = document.getElementById("submit");

    submitButton.addEventListener("click", function () {
        const emailValue = emailInput.value.trim();
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

        if (!emailRegex.test(emailValue)) {
            alert("Please enter a valid email address.");
        }
    });
});

/* validation of valid password (8 or more character long) */
function checkPassword() 
{
    var passwordInput = document.getElementById("passw").value;
    if (passwordInput.length < 8) {
        alert("Password must be 8 characters or longer.");
    } else {
        alert("Password is valid!");
    }
}

/* switch from set-reminder button to medication-reminder form */
document.addEventListener("DOMContentLoaded", function () 
{
    const addReminderButton = document.getElementById("addreminder");
    const medicationReminderForm = document.getElementById("medication-reminder");

    addReminderButton.addEventListener("click", function () 
    {
        const computedStyle = window.getComputedStyle(medicationReminderForm);

        if (computedStyle.display === 'none' || computedStyle.display === '') 
        {
            medicationReminderForm.style.display = 'block';
        } else {
            medicationReminderForm.style.display = 'none';
        }
    });
});

/* Landing page scrolling */
document.addEventListener("DOMContentLoaded", function() {
    const navigationLinks = document.querySelectorAll('.navigation a');

    navigationLinks.forEach(link => {
        link.addEventListener('click', function(event) {
            event.preventDefault(); 
            const targetId = this.getAttribute('href'); 
            const targetSection = document.querySelector(targetId); 
            if (targetSection) {
                const offsetTop = targetSection.offsetTop;
                window.scrollTo({
                    top: offsetTop,
                    behavior: "smooth" 
                });
            }
        });
    });
});